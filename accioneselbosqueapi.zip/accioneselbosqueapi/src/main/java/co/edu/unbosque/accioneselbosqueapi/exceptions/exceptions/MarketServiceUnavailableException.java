package co.edu.unbosque.accioneselbosqueapi.exceptions.exceptions;

public class MarketServiceUnavailableException extends RuntimeException {

    public MarketServiceUnavailableException(String message) {
        super(message);
    }
}
