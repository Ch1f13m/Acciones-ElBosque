package co.edu.unbosque.accioneselbosqueapi.exceptions.exceptions;

public class WatchlistNotFoundException extends RuntimeException {

    public WatchlistNotFoundException(String message) {
        super(message);
    }
}
