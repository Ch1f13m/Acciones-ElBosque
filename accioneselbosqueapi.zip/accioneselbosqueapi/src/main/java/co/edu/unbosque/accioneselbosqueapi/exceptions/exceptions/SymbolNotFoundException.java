package co.edu.unbosque.accioneselbosqueapi.exceptions.exceptions;

public class SymbolNotFoundException extends RuntimeException {

    public SymbolNotFoundException(String message) {
        super(message);
    }
}
