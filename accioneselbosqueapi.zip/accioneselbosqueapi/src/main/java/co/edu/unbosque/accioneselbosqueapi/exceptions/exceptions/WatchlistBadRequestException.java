package co.edu.unbosque.accioneselbosqueapi.exceptions.exceptions;

public class WatchlistBadRequestException extends RuntimeException {

    public WatchlistBadRequestException(String message) {
        super(message);
    }
}
