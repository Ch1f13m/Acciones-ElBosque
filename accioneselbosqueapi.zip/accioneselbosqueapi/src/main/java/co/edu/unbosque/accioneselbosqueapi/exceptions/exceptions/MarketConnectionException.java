package co.edu.unbosque.accioneselbosqueapi.exceptions.exceptions;

public class MarketConnectionException extends RuntimeException {
    public MarketConnectionException(String message) {
        super(message);
    }
}
