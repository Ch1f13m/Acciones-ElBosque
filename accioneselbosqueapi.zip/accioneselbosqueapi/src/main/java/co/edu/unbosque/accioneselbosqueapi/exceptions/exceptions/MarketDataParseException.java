package co.edu.unbosque.accioneselbosqueapi.exceptions.exceptions;

public class MarketDataParseException extends RuntimeException {

    public MarketDataParseException(String message) {
        super(message);
    }
}